package BJGUIFrame;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;

import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import BJGUICard.BJCard;

public class BJChatComponent extends Thread {
	public static JTextField chatLine;
	public static JTextArea chatText;
	private BJChatPanel bjChatPanel;
	private String name;
	Socket socket;
	BJCard card;
	PrintWriter printWriter;
	BufferedReader bufferedReader;
	
	private BJMainFrame bjMainFrame;

	public void setBlank() {
		String cmd = chatLine.getText().split(">")[0];
		//if (!(cmd.equals("more") || cmd.equals("bet")))
	//		chatText.append(chatLine.getText() + "\n");
		chatLine.setText("");
	}

	private void makeChat() {
		// TODO Auto-generated method stub
		chatText = new JTextArea(5, 20);
		chatText.setEditable(true);
		chatText.setForeground(Color.blue);
		chatText.setBackground(Color.red);

		JScrollPane chatTextPane = new JScrollPane(chatText,
				JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
				JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);

		chatLine = new JTextField();
		chatLine.setEnabled(true);
		chatLine.setEditable(true);
		chatText.setEditable(false);
		chatLine.setText("");
		chatText.setText("");

		chatLine.addKeyListener(new KeyListener() {

			@Override
			public void keyTyped(KeyEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void keyReleased(KeyEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void keyPressed(KeyEvent e) {
				// TODO Auto-generated method stub
				int key = e.getKeyCode();

				if (chatLine.getText().length() != 0
						&& key == KeyEvent.VK_ENTER) {

					try {
						System.out.println("send msg");
						printWriter.println(name + " ( "
								+ InetAddress.getLocalHost().getHostAddress()
								+ " ) " + "> " + chatLine.getText());
						printWriter.flush();
						card.drawCard();
						setBlank();
					} catch (UnknownHostException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
			}
		});
		bjChatPanel.add(chatTextPane, BorderLayout.CENTER);
		bjChatPanel.add(chatLine, BorderLayout.SOUTH);
	}

	public void init(BJChatPanel bjChatPanel, PrintWriter printWriter,
			BufferedReader bufferedReader, BJMainFrame bjMainFrame) {
		// TODO Auto-generated method stub
		this.bjChatPanel = bjChatPanel;
		this.printWriter = printWriter;
		this.bufferedReader = bufferedReader;
		this.bjMainFrame = bjMainFrame;
		card = bjChatPanel.getPanel().getCard();
		makeChat();
		name = JOptionPane.showInputDialog(null, "Enter Your Name : ",
				"Name Input", 1);
		bjMainFrame.getName(name);
	}

	public void print(String str) {
		// TODO Auto-generated method stub
		chatText.append(str+"\n");
	}
}