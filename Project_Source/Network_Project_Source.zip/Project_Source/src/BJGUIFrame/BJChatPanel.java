package BJGUIFrame;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.io.BufferedReader;
import java.io.PrintWriter;

import javax.swing.JPanel;

public class BJChatPanel extends JPanel {

	private BJChatComponent compo;
	private BJPanel blackJackPanel;
	private BJMainFrame bjMainFrame;
	
	public BJChatPanel(){
		super(new BorderLayout());
		this.setPreferredSize(new Dimension(200, 700));	
	}

	public void init(BJPanel blackJackPanel, PrintWriter printWriter,
			BufferedReader bufferedReader, BJMainFrame bjMainFrame) {
		// TODO Auto-generated method stub
		this.blackJackPanel = blackJackPanel;
		compo = new BJChatComponent();
		compo.init(this, printWriter, bufferedReader, bjMainFrame);
	}

	public void showButton() {
		// TODO Auto-generated method stub
	}

	public BJPanel getPanel() {
		// TODO Auto-generated method stub
		return blackJackPanel;
	}

	public void print(String str) {
		// TODO Auto-generated method stub
		compo.print(str);
	}
}
