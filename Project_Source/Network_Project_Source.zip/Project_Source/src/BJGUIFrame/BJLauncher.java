package BJGUIFrame;

public class BJLauncher {
	public static void main(String[] args){
		BJMainFrame frame = BJMainFrame.getInstance();
		frame.init();
	}
}
