package BJGUIFrame;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.WindowConstants;

import BJGUICard.BJCard;
import BJGUIConstant.BJConstant;
import BJGUIMenus.BJMenuBar;
import client.Client;

@SuppressWarnings("serial")
public class BJMainFrame extends JFrame implements Runnable {

	private static BJMainFrame MainFrame = new BJMainFrame(
			BJConstant.TITLE_MAINFRAME);
	private BJPanel blackJackPanel;
	private BJMenuBar menuBar;
	private BJToolbar toolBar;
	private BJChatPanel chatPanel;
	private BJCard card;
	private JButton button;
	Socket socket;
	PrintWriter printWriter;
	BufferedReader bufferedReader;

	String myName;
	BJMainFrame bjMainFrame;

	public BJMainFrame(String title) {
		super(title);

		bjMainFrame = this;

		try {
			socket = new Socket("117.17.158.171", 9995);
		//	socket = new Socket("192.168.41.185", 9995);
			bufferedReader = new BufferedReader(new InputStreamReader(
					socket.getInputStream()));
			printWriter = new PrintWriter(new OutputStreamWriter(
					socket.getOutputStream()));
		} catch (UnknownHostException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		} catch (IOException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}

		blackJackPanel = new BJPanel();
		add(blackJackPanel);
		menuBar = new BJMenuBar();
		setJMenuBar(menuBar);
	//	toolBar = new BJToolbar(BJConstant.TITLE_TOOLBAR);
	//	add(BorderLayout.NORTH, toolBar);
		chatPanel = new BJChatPanel();
		add(BorderLayout.EAST, chatPanel);
		card = new BJCard();
		button = new JButton("Join");
		button.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				if (button.getText().equals("Join")) {
					try {
						// String msg = bufferedReader.readLine();
						// System.out.println(msg);

						printWriter.println("( "
								+ InetAddress.getLocalHost().getHostAddress()
								+ " ) " + "> " + "join> yes");
						printWriter.flush();
					} catch (UnknownHostException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					button.setText("Start");
				} else if (button.getText().equals("Start")) {
					try {
						printWriter.println("( "
								+ InetAddress.getLocalHost().getHostAddress()
								+ " ) " + "> " + "start> yes");
						printWriter.flush();
						button.setVisible(false);
					} catch (UnknownHostException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
			}
		});
		blackJackPanel.addButton(button);
	}

	public static BJMainFrame getInstance() {
		return MainFrame;
	}

	public void init() {
		blackJackPanel.setCard(card);
		menuBar.init(blackJackPanel);
	//	toolBar.init(blackJackPanel);
		chatPanel.init(blackJackPanel, printWriter, bufferedReader, this);
		card.init(blackJackPanel);

		setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		setSize(BJConstant.WIDTH_MAINFRAME, BJConstant.HEIGHT_MAINFRAME);
		setVisible(true);
		setResizable(false);

		Thread thread = new Thread(bjMainFrame);
		thread.start();
	}

	public void run() {
		String str;
		while (true) {
			try {
				String temp[] = new String[5];
				String tmp[] = new String[10];
				// String list[] = null;

				str = bufferedReader.readLine();
				System.out.print("Read the Line  ");
				if(str != null){ 
				
				if (str != null)
					System.out.println(str);
				
				temp = str.split(" : ");
				// list = str.split("> ");
				if (temp[0].equals("Dealer")) {
					tmp = temp[1].split(" ");
					for (String t : tmp) {
						String ta = makeCard(t.substring(0, 1),
								t.substring(1, t.length()));

						System.out.println("recieve card" + ta);
						card.addCard(ta, 530, 50, true);
					}
				} else if (temp[0].equals("User")) {
					tmp = temp[1].split(" ");
					for (String t : tmp) {
						if(t.equals("user")){
							continue;
						}
						if(t.length() == 2 || t.length() == 3){
							continue;
						}
						String ta = makeCard(t.substring(7, 8),
								t.substring(8, t.length()));
						if(t.subSequence(0, 7).equals("player1")){
							card.addCard(ta, 860, 400, false);
						} else if(t.subSequence(0, 7).equals("player2")){
							card.addCard(ta, 630, 400, false);
						} else if(t.subSequence(0, 7).equals("player3")){
							card.addCard(ta, 350, 400, false);
						} else if(t.subSequence(0, 7).equals("player4")){
							card.addCard(ta, 130, 400, false);
						}
					}
				} else if (str.length() > 5
						&& str.substring(0, 5).equals("inmsg")) {
					int betting = Integer.parseInt(JOptionPane.showInputDialog(
							null,
							myName + " " + str.substring(5, str.length()),
							"Input A Value", 1));
					printWriter.println("( "
							+ InetAddress.getLocalHost().getHostAddress()
							+ " ) " + "> " + "bet> " + betting);
					printWriter.flush();
				} else if (str.length() > 3
						&& str.substring(0, 3).equals("msg")) {
					JOptionPane.showMessageDialog(null,
							myName + " " + str.substring(3, str.length()),
							"Attention!!", 1);
				} else if (str.length() > 5
						&& str.substring(0, 5).equals("domsg")) {

					int yorn = 0;

					yorn = JOptionPane.showConfirmDialog(null, myName + " "
							+ str.substring(5, str.length()), "Yes or No??", 2);
					
					if (yorn == 0) {
						printWriter.println("( "
								+ InetAddress.getLocalHost().getHostAddress()
								+ " ) " + "> " + "more> yes");
						printWriter.flush();
						
						System.out.println("send more yes");
					} else if(yorn == 2){
						printWriter.println("( "
								+ InetAddress.getLocalHost().getHostAddress()
								+ " ) " + "> " + "more> no");
						printWriter.flush();
					}
				} else if (str.length() > 6
						&& str.substring(0, 6).equals("conmsg")) {

					int yorn = 0;

					yorn = JOptionPane.showConfirmDialog(null, myName + " "
							+ str.substring(6, str.length()-1), "Yes or No??", 2);
					
					if (yorn == 0) {
						printWriter.println("( "
								+ InetAddress.getLocalHost().getHostAddress()
								+ " ) " + "> " + "join> yes");
						printWriter.flush();
						
						
					} else if(yorn == 2){
						printWriter.println("( "
								+ InetAddress.getLocalHost().getHostAddress()
								+ " ) " + "> " + "join> no");
						printWriter.flush();
					}
					Thread.sleep(2000);
					card.resetList();
					
					
				} else {
					System.out.println(str);
					chatPanel.print(str);
				}
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}



	private String makeCard(String substring, String substring2) {
		// TODO Auto-generated method stub
		String cardName = null;
		switch (substring.charAt(0)) {
		case 'C':
			cardName = "Clover_" + substring2;
			break;
		case 'H':
			cardName = "Heart_" + substring2;
			break;
		case 'S':
			cardName = "Spade_" + substring2;
			break;
		case 'D':
			cardName = "Diamond_" + substring2;
			break;
		}
		return cardName;
	}

	public void getName(String name) {
		this.myName = name;
	}

}
