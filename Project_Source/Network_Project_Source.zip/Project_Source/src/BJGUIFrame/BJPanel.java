package BJGUIFrame;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.io.BufferedReader;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import BJGUICard.BJCard;
import BlackJack.Card;


@SuppressWarnings("serial")
public class BJPanel extends JPanel {
	
	Graphics2D g2d;
	BJCard card;
	private ArrayList<Point> userPointList;
	private ArrayList<String> userCardList;
	private ArrayList<Point> dealerPointList;
	private ArrayList<String> dealerCardList;
	BufferedReader bufferedReader;
	BJPanel bjpanel;
	
	public BJPanel() {
		super();
		bjpanel = this;
	}
	
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
	    ImageIcon icon;
		icon = new ImageIcon("images/rePan1.gif");
		userPointList = card.getUserPointList();
		userCardList = card.getUserCardList();
		dealerPointList = card.getDealerPointList();
		dealerCardList = card.getDealerCardList();
		 //  Approach 1: Display image at at full size
        g.drawImage(icon.getImage(), 0, 0, null);
       
       card.setG2d((Graphics2D)g);
        setOpaque(false);
       // System.out.println(getGraphics());
     //card.drawCard("Clover_10", 860, 330);
        //player 1
        
        //card.drawCard("Clover_10", 630, 400);
        // player2
        
       // card.drawCard("Clover_10", 350, 400);
        // player3
        
      //  card.drawCard("Clover_10", 130, 325);
        // player4
        for(int i =0;i < userCardList.size();i++){
//			ImageIcon cardImage1;
//			cardImage1 = new ImageIcon("images/Card/"+cardList.get(i)+".png");
//			System.out.println("images/Card/"+cardList.get(i)+".png");
			String tempStr = userCardList.get(i);
			Point tempPoint = userPointList.get(i);
			card.drawCard(tempStr,(int)tempPoint.getX()-i*20, (int)tempPoint.getY());
//			g2d.finalize();
		}
        
        for(int i =0;i < dealerCardList.size();i++){

			String tempStr = dealerCardList.get(i);
			Point tempPoint = dealerPointList.get(i);
			card.drawCard(tempStr,(int)tempPoint.getX()-i*20, (int)tempPoint.getY());

		}
        
        
        repaint();
	}
	
	public void setCard(BJCard card) {
		// TODO Auto-generated method stub
		this.card = card;
	}

	public void addButton(JButton button) {
		// TODO Auto-generated method stub
		button.setLocation(500,500);
		this.add(button);
	}
	
	public BJCard getCard() {
		// TODO Auto-generated method stub
		return card;
	}
}