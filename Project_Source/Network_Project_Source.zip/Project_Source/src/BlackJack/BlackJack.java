package BlackJack;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Vector;

import javax.swing.JOptionPane;

import chatting.ChattingRoom;

public class BlackJack extends Thread {

	private CardSet card = null;
	private User dealer = null;
	private ArrayList<User> gamer = new ArrayList<User>();
	public String inputStr = "";
	public String okNo = "";
	private ArrayList<Socket> playerList;
	private ChattingRoom chatRoom;
	int checkCount;

	

	private Socket socket;

	public BlackJack(ArrayList<Socket> playerList, chatting.ChattingRoom chat,
			Socket socket) throws IOException {
		this.playerList = playerList;
		this.chatRoom = chat;
		System.out.println(playerList + " " + playerList.size());
		this.socket = socket;

		//bjState = crState;

		init(playerList);
	}

	public void print(String msg, ArrayList<Socket> playerList) {

		for (Socket s : playerList) {
			try {
				System.out
						.println(s.toString() + playerList.indexOf(s) + "sel");
				PrintWriter printWriter = null;
				printWriter = new PrintWriter(new OutputStreamWriter(
						s.getOutputStream()));
				printWriter.println(msg);
				printWriter.flush();
			} catch (IOException e) {
				playerList.remove(s);
			}
		}
	}

	public void println(String msg, ArrayList<Socket> playerList) {
		for (Socket s : playerList) {
			try {
				PrintWriter printWriter = null;
				printWriter = new PrintWriter(new OutputStreamWriter(
						s.getOutputStream()));
				printWriter.print(msg);
				printWriter.flush();
			} catch (IOException e) {
				playerList.remove(s);
			}
		}
	}

	public void print(String msg, Socket player) {
		try {
			PrintWriter printWriter = null;
			printWriter = new PrintWriter(new OutputStreamWriter(
					player.getOutputStream()));
			printWriter.println(msg);
			System.out.println(msg + " sending");
			printWriter.flush();
		} catch (IOException e) {
			// System.out.println("IOException");
		}
	}

	private void init(ArrayList<Socket> playerList) throws IOException {

		String msg = "Welcome to the BlackJack World!!!";
		print("msg" + msg, this.playerList);

		dealer = new User("Dealer", 100000 * 10); // ������ ���� �ڱ��� 10�踦
		// ������ �����Ѵ�.

		msg = "���� �غ� �Ϸ�. �ܾ� = " + dealer.getMoney();
		print(msg, this.playerList);
		System.out.println("dealer ok " + playerList);

		for (Socket socket : this.playerList) {
			adduser(socket.getInetAddress().getHostAddress());
		}
	}

	public void run() {
		try {
			startGame();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void adduser(String name) {
		User gambler = new User(name, 100000);
		gamer.add(gambler);
		System.out
				.println("gambler " + gamer + "  gambler size" + gamer.size());

		//bjState.addSuperList(gambler);
	//	System.out.println("bjState" + bjState.getSuperList());

		print(gamer.toString(), this.playerList);
		print(playerList.toString(), this.playerList);

		gambler.initCard();

		String msg = "����� �غ� �Ϸ�. �ܾ� = " + gambler.getMoney();
		print("msg" + msg, this.playerList);
	}

	private void startGame() throws IOException {
		card = new CardSet();
		dealer.initCard();
		for (User user : gamer)
			user.initCard();

		String msg = "ī�弼Ʈ ���� �Ϸ�.";
		print(msg, this.playerList);
		//bjState.setCardSet(card);
		chatRoom.setCard(card);
		
		game();
	}

	public void game() throws IOException {
		try {
			//bjState.setSuperList(gamer);
			//System.out.println("bjState" + bjState.getSuperList());
			// ���þ� �Է�
			dealer.addCard(card.getRamdomCard());
			dealer.addCard(card.getRamdomCard());
			for (User user : gamer) {
				inputMoney(user);
				user.addCard(card.getRamdomCard());
				user.addCard(card.getRamdomCard());
			}

			// showCard(true);
			do {
				inputStr = "";
				okNo = "";
				for (User user : gamer) {
					if (user.getMoney() >= 0) {
						
						// ���� ī�尡 21�� �ȳ��� ��츸 �� ������ ����
						if (getValue(user.getCard()) < 21) {
							
							
								showCard(false);
								print("domsg" + "��. ī�带 �� �����ðڽ��ϱ�? (Y/N)"
										+ " ���� �� : " + getValue(user.getCard()),
										playerList.get(gamer.indexOf(user)));
								
								
							
							while(true){
							if (inputStr != null && inputStr.equals("n")) {
								print("conmsg" + "��. ��� �Ͻðڽ��ϱ�? (Y/N):",
										this.playerList.get(gamer.indexOf(user)));
									checkCard();
									
								do {
						//			System.out.println("  ");
								} while (!(okNo.equals("y") || okNo.equals("n")));
									user.setBetting(0);
									inputStr = null;
									newGame();
									break;
								} else if (inputStr  != null && inputStr.equals("y")) {
								
									user.addCard(card.getRamdomCard());
									
									System.out.println("add Card comple");
									inputStr = null;
									break;
								}
							}
						} else {
							checkCard();
							print("conmsg" + "��. ��� �Ͻðڽ��ϱ�? (Y/N):",
									this.playerList);
							do {
							//	System.out.println("  ");
							} while (!(okNo.equals("y") || okNo.equals("n")));
							user.setBetting(0);
							newGame();
							return;
						}
					} else {
						print("msg" + "��, �ܾ��� �����ϴ�. ������ �ٽ� ������� �ֽʽÿ�.",
								playerList.get(gamer.indexOf(user)));
						try {
							chatRoom.toSocket().close();
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}checkCard();
				}
			} while (true);
		} catch (NumberFormatException e) {
			System.out.println("���ڸ� �Է��ϼž� �մϴ�.");
		}
	}

	public void newGame() throws IOException {
		int myNumber = 1;
		if (okNo.equals("y")) {
			startGame();
		} else if (okNo.equals("n")) {
			for (int i = 0; i < playerList.size(); i++) {
				if (playerList.get(i) == chatRoom.toSocket()) {
					myNumber = i;
				}
			}
			playerList.remove(myNumber);
			chatRoom.playerCount--;
			try {
				chatRoom.toSocket().close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	private void showMoney() {
		String msg = " �� ���� �ܰ� = " + dealer.getMoney();
		print("msg" + msg, playerList);
		for (User user : gamer) {
			msg = " �� �ܰ� = " + user.getMoney() + "�Դϴ�.";
		}
		print("msg" + msg, playerList);
	}

	public String showCard(boolean isDealerCardShow) {
		Vector<Card> dealerCard = dealer.getCard();

		String msg = "Dealer : ";
		println(msg, this.playerList);
		if (isDealerCardShow) {

			for (int i = 0; i < dealerCard.size(); i++) {
				msg = ((Card) dealerCard.get(i)).getCardName() + " ";
				println(msg, this.playerList);
				msg += ((Card) dealerCard.get(i)).getCardName() + " ";
			}

			msg = "�� = " + getValue(dealer.getCard()) + "\n";
			println(msg, this.playerList);

		} else {
			msg = ((Card) dealerCard.get(0)).getCardName() + "\n";// +
																	// " �Ⱥ��̴� ī��\n";
			println(msg, this.playerList);
		}

		for (User user : gamer) {
			Vector<Card> userCard = user.getCard();
			msg = "User : ";
			
			for (int i = 0; i < userCard.size(); i++) {
				if(gamer.indexOf(user) == 0){
					println(msg, this.playerList);
					msg = ((Card) userCard.get(i)).getCardName() + " ";
					println("player1" + msg, this.playerList);
					msg += ((Card) userCard.get(i)).getCardName() + " ";
				} else if (gamer.indexOf(user) == 1){
					msg = ((Card) userCard.get(i)).getCardName() + " ";
					println("player2" + msg, this.playerList);
					msg += ((Card) userCard.get(i)).getCardName() + " ";
				} else if (gamer.indexOf(user) == 2){
					msg = ((Card) userCard.get(i)).getCardName() + " ";
					println("player3" + msg, this.playerList);
					msg += ((Card) userCard.get(i)).getCardName() + " ";
				} else if (gamer.indexOf(user) == 3){
					msg = ((Card) userCard.get(i)).getCardName() + " ";
					println("player4" + msg, this.playerList);
					msg += ((Card) userCard.get(i)).getCardName() + " ";
				} 
//				println(msg, this.playerList);
//				msg += ((Card) userCard.get(i)).getCardName() + " ";
			}
			msg = "\n�� = " + getValue(user.getCard()) + "\n";
			if(playerList.get(gamer.indexOf(user)).equals(socket)){
				println(msg, this.playerList);
			}
		}
		return msg;
	}

	private int getValue(Vector<Card> card) {
		int i = 0;
		int value = 0;
		int aceCount = 0;

		for (i = 0; i < card.size(); i++) {
			value += ((Card) card.get(i)).getCardValue();
			if (((Card) card.get(i)).getCardValue() == 1) {
				aceCount++;
			}
		}

		for (i = 0; i < aceCount; i++) {
			if (value <= 11) {
				aceCount--;
				value += 10;
			}
		}
		return value;
	}

	private boolean getResult() {
		int bettingMoney;
		int dealerValue = getValue(dealer.getCard());
		
		while(dealerValue < 17){
			dealer.addCard(card.getRamdomCard());
			dealerValue = getValue(dealer.getCard());
		}
		for (User user : gamer) {
			int userValue = getValue(user.getCard());
			bettingMoney = user.getBetting();
			if (userValue > 21
					|| (dealerValue <= 21 && userValue < 21 && dealerValue > userValue)) {
				// ������ 21�� �ʰ��ϰų� , �� �� 21�� ���� �����鼭 ������ ���� �� �϶�
				String msg = " ���� �ο�, ���� ��";
				print(showCard(true), playerList);
				print("msg" + msg, playerList.get(gamer.indexOf(user)));
				dealer.addMoney(bettingMoney);
				System.out.println("betting" + bettingMoney);
				System.out.println(user.getMoney() + " "
						+ (user.getMoney() - bettingMoney));
			} else if (userValue > dealerValue || dealerValue > 21) {
				System.out.println(user.getUserName() + " ��");
				print(showCard(true), playerList);
				String msg = " ��";
				print("msg" + msg, playerList.get(gamer.indexOf(user)));
				System.out.println("betting" + bettingMoney);
				System.out.println(user.getMoney() + " "
						+ (user.getMoney() + (int) (bettingMoney * 1.5)));
				dealer.minusMoney(bettingMoney);
				user.addMoney((int) (bettingMoney * 1.5));
			} else if (userValue == dealerValue) {
				System.out.println(user.getUserName() + "���º�");
				print(showCard(true), playerList);
				String msg = "���º�";
				print("msg" + msg, playerList.get(gamer.indexOf(user)));
				user.addMoney(bettingMoney);
			} else {
				print(showCard(true), playerList);
				System.out.println("���� ���� �ȵǾ�����.");
			}
		}
		return true;
	}

	// betting check
	private void inputMoney(User user) throws IOException {
		int betting = 0;

	
			String msg = "�� ���þ��� �Է��ϼ��� (���� �ݾ� : " + user.getMoney() + "): ";
			print("inmsg" + msg, playerList.get(gamer.indexOf(user)));

			do {
				if ((user.getBetting() != 0) && (user.getBetting() < 1)) {
					msg = "�ݾ��� 1�� �̻� �����մϴ�.";
					System.out.println(user.getMoney() + " "
							+ user.getBetting() + " ");
					print("msg" + msg, this.playerList);
					user.setBetting(0);
					continue;
				} else if ((user.getBetting() != 0)
						&& (user.getBetting() > user.getMoney())) {
					System.out.println(user.getBetting() + " "
							+ gamer.get(0).getMoney() + " " + user.getMoney()
							+ (user.getBetting() > user.getMoney()));
					msg = "�����ݾ� �̻� ������ �Ұ��մϴ�.";
					System.out.println(user.getMoney() + " "
							+ user.getBetting() + " ");
					print("msg"
							+ msg
							+ ("�����ݾ� : " + user.getMoney() + " , ���ñݾ� : " + user
									.getBetting()),
							this.playerList);
					user.setBetting(0);
					continue;
				}
			} while (user.getBetting() == 0);
			System.out.println("");
			betting += user.getBetting();
			user.minusMoney(user.getBetting());
		
	}

	public Vector<Card> getCard(int i) {
		// TODO Auto-generated method stub
		return gamer.get(i).getCard();
	}

	

	public CardSet getCard() {
		// TODO Auto-generated method stub
		System.out.println("Be" + card.toString());
		return card;
	}

	public ArrayList<Socket> getPlayerList() {
		// TODO Auto-generated method stub
		return playerList;
	}

	public ArrayList<User> getGamer() {
		// TODO Auto-generated method stub
		
		return gamer;
	}

	public void checkCard() {
		// TODO Auto-generated method stub
		checkCount++;
		if(checkCount == playerList.size()){
			getResult();
			showMoney();
		}
	}
}
