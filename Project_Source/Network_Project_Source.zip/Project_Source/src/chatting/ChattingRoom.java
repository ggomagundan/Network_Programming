package chatting;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.ArrayList;

import javax.swing.JOptionPane;

import sun.management.counter.Units;

import BlackJack.BlackJack;
import BlackJack.CardSet;
import BlackJack.User;

public class ChattingRoom extends Thread {

	private ArrayList<Socket> socketList;
	public static ArrayList<Socket> playerList = null;
	private Socket socket;
	private static String msg = null;
	public BlackJack bj;
	public static CardSet card;
	public static int playerCount = 0;
	public static ArrayList<User> gamer = null;


	public ChattingRoom(Socket socket, ArrayList<Socket> socketList)
			throws IOException {
		this.socket = socket;
		this.socketList = socketList;
		if (playerList == null) {
			playerList = new ArrayList<Socket>();
		}
		
	}

	public Socket toSocket() {
		return socket;
	}

	public void run() {
		BufferedReader bufferedReader = null;
		PrintWriter printWriter = null;
		try {
			bufferedReader = new BufferedReader(new InputStreamReader(
					socket.getInputStream()));
			String[] list = null;
			while (true) {
				msg = bufferedReader.readLine();

				if (msg == null || msg.equals("null")) {
					throw new IOException(" Client Socket Error : ");
				}
				list = msg.split("> ");

				if (list.length >= 3 && list[1].equals("join")
						&& list[2].equals("yes")) {

					if (!playerList.contains(socket)) {
						playerList.add(socket);
						System.out.println(socket
								+ "is Join this Game playerList isze "
								+ playerList.size());

						}
						if (bj != null) {
							bj.okNo = "y";
					}

				} else if (list.length >= 3 && list[1].equals("join")
						&& list[2].equals("no")) {

					if (bj != null) {
						bj.okNo = "n";
					}

				} else if (list.length >= 3 && list[1].equals("start")
						&& list[2].equals("yes")) {

					System.out.println(socket);
					playerCount++;
					System.out.println("playersize is " + playerList.size()
							+ "  socketList " + socketList.size());
					if (playerCount == socketList.size()) {

						System.out.println("playersize is " + playerList.size()
								+ "  socketList " + socketList.size());
							System.out.println("game STart");
							
							bj = new BlackJack(playerList, this, socket
									);
							init();
							bj.start();
							
						
					}

				} else if (list.length >= 3 && list[1].equals("bet")) {
					
				//	crState.init(this);
				//	System.out.println("crState = " + crState.getSuperList());
				//	gamer = crState.getSuperList();
					
					
					gamer.get(
							playerList.indexOf(
									socket)).setBetting(
							Integer.parseInt(list[2].toString()));

				} else if (list.length >= 3 && list[1].equals("more")) {
					if (list[2].equals("yes")) {
					//	crState.init(this);
						System.out.println("recieve more yes");
					//	System.out.println("crState = " + crState.getSuperList());
					//	gamer = crState.getSuperList();
						
						System.out.println("comple add carD");
						
						//System.out.println(bj);
						bj.inputStr = "y";
						
					} else if (list[2].equals("no")) {
						//crState.init(this);
						//System.out.println("crState = " + crState.getSuperList());
					//	gamer = crState.getSuperList();
						bj.checkCard();
						bj.inputStr = "n";
					}
				} else {
					System.out.println(msg);

					for (Socket s : socketList) {
						// System.out.println(s.toString() + "select");
						// �����Դ� �ѷ����� �ʴ´�.
						if (s == socket) {
							continue;
						}
						// �Ѹ��� ����.
						try {
							printWriter = new PrintWriter(
									new OutputStreamWriter(s.getOutputStream()));

							System.out.println("Send the msg");
							printWriter.println(msg);
							printWriter.flush();
						} catch (IOException e) {
							socketList.remove(s);
						}
					}
				}
			}
		} catch (IOException e) {
			socketList.remove(socket);
		} finally {
			try {
				if (bufferedReader != null) {
					bufferedReader.close();
				}
			} catch (Exception ignored) {
			}
			try {
				if (socket != null) {
					socket.close();
				}
			} catch (Exception ignored) {
			}
		}
	}

	private void init() {
		// TODO Auto-generated method stub
		gamer = bj.getGamer();
		System.out.println("get Gamer" + gamer);
		
	}

	public void setCard(CardSet card2) {
		// TODO Auto-generated method stub
		this.card = card2;
	}
}
