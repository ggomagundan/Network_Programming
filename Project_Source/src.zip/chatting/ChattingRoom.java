package chatting;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;

public class ChattingRoom extends Thread {

	private static BufferedReader bufferRead = new BufferedReader(
			new InputStreamReader(System.in));
	private static PrintWriter printWriter;
	private static BufferedReader bufferedReader;

	public ChattingRoom(Socket socket) throws IOException {
		this.bufferedReader = new BufferedReader(new InputStreamReader(
				socket.getInputStream()));
		this.printWriter = new PrintWriter(new OutputStreamWriter(
				socket.getOutputStream()));
	}

	public void run() {
		while (true) {
			try {
				String msg = bufferedReader.readLine();
				if (msg == null || msg.equals("null")) {
					throw new IOException("Network Failed");
				}
				System.out.println(msg);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
}
