package client;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.Socket;

import chatting.ChattingRoom;

import BlackJack.BlackJack;

public class Client{

	private Socket socket;
	private BufferedReader bufferedReader;
	private PrintWriter printWriter;
	private static BufferedReader bufferRead = new BufferedReader(
			new InputStreamReader(System.in));

	public Client() {

		try {
			socket = new Socket("192.168.71.49", 9995);
			bufferedReader = new BufferedReader(new InputStreamReader(
					socket.getInputStream()));
			printWriter = new PrintWriter(new OutputStreamWriter(
					socket.getOutputStream()));

			while (true) {
				try {
					String msg = bufferRead.readLine();
					printWriter.println(InetAddress.getLocalHost().getHostAddress()
							+ " > " + msg);
					printWriter.flush();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (bufferedReader != null)
					bufferedReader.close();
			} catch (Exception ignored) {
			}
			try {
				if (printWriter != null)
					printWriter.close();
			} catch (Exception ignored) {
			}
			try {
				if (socket != null)
					socket.close();
			} catch (Exception ignored) {
			}
		}

	}

/*	public void run() {
		while (true) {
			try {
				String msg = bufferRead.readLine();
				printWriter.println(InetAddress.getLocalHost().getHostAddress()
						+ " > " + msg);
				printWriter.flush();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}  */

	public static void main(String[] args) {
		new Client();
	}
}
