package server;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

import BlackJack.BlackJack;
import chatting.ChattingRoom;

public class Server {

	private ServerSocket serverSocket;
	private boolean isGameStart = false;
	private static int card_Count = 52;

	private ArrayList<Socket> socketList;

	public Server() {

		socketList = new ArrayList<Socket>();
		
		try {
			serverSocket = new ServerSocket(9995);

			while (true) {
				System.out.println("�÷��̾��� ������ ��ٸ��� ��...");
				Socket socket = serverSocket.accept();

				BlackJack bj = new BlackJack();
				ChattingRoom cr = new ChattingRoom(socket);
				bj.start();
				cr.start();
				
				if (isGameStart == false) {
					card_Count -= 2;
					System.out.println("I Have 2 cards");
					isGameStart = true;
				}

				OutputStream out = socket.getOutputStream();
//				InputStream in = socket.getInputStream();
//				BufferedReader br = new BufferedReader(new InputStreamReader(in));
				PrintWriter pw = new PrintWriter(new OutputStreamWriter(out));
				card_Count -= 2;
				pw.println("I Bring 2 card you");
				pw.flush();
				System.out.println("I Have " + card_Count + " Cards");

				if (!socketList.contains(socket)) {
					socketList.add(socket);
					MessageHandler messageHandler = new MessageHandler(socket,
							socketList);
					Thread thread = new Thread(messageHandler);
					thread.start();
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				serverSocket.close();
			} catch (Exception ignored) {
			}
		}
	}

	public class MessageHandler implements Runnable {

		private Socket socket;
		private ArrayList<Socket> socketList;

		public MessageHandler(Socket socket, ArrayList<Socket> socketList) {
			this.socket = socket;
			this.socketList = socketList;
		}

		public void run() {

			BufferedReader bufferedReader = null;
			PrintWriter printWriter = null;
			try {
				bufferedReader = new BufferedReader(new InputStreamReader(
						socket.getInputStream()));

				while (true) {
					
					String msg = bufferedReader.readLine();
					
					if (msg == null || msg.equals("null"))
						throw new IOException(" Client Socket Error : ");

					System.out.println(msg);

					for (Socket s : socketList) {
						if (s == socket)
							continue;

						try {
							printWriter = new PrintWriter(
									new OutputStreamWriter(s.getOutputStream()));

							printWriter.println(msg);
							printWriter.flush();

						} catch (IOException e) {
							socketList.remove(s);
						}
					}
				}
			} catch (IOException e) {
				socketList.remove(socket);
			} finally {
				try {
					if (bufferedReader != null)
						bufferedReader.close();
				} catch (Exception ignored) {
				}
				try {
					if (socket != null)
						socket.close();
				} catch (Exception ignored) {
				}
			}
		}
	}

	public static void main(String[] args) {
		new Server();
	}

	public static void wantCard(Socket socket) throws IOException {
		OutputStream out = socket.getOutputStream();
		InputStream in = socket.getInputStream();
		PrintWriter pw = new PrintWriter(new OutputStreamWriter(out));
		BufferedReader br = new BufferedReader(new InputStreamReader(in));
		System.out.println(br.readLine());
		card_Count -= 1;
		pw.println("I Bring 1 card you");
		pw.flush();
		System.out.println("I Have " + card_Count + " Cards");
	}
}